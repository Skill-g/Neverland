export const siteName = "Neverland"
export const HOME_ROUTE = "/"
export const TICKET_ROUTE = "/ticket"