import styles from "./styles.module.css";
import {siteName} from "../../../app/consts.ts";

export const leftMenu = () => {
    return (
        <div className={styles.leftMenuContainer}>
            <div className={`${styles.leftMenu}`}>
                <div className="mt-5">
                    <p className={`${styles.title}`}>{siteName}</p>
                </div>
                <div className={`${styles.buttons}`}>
                    <div className={styles.button}>
                        <img src="/pictures/notepad-text.svg" alt="reqestes"/>
                        <button title="Заявки">
                            Заявки
                        </button>
                    </div>
                    <div className={styles.button}>
                        <img src="/pictures/star.svg" alt="reqestes"/>
                        <button title="Организации">
                            Организации
                        </button>
                    </div>
                    <div className={styles.button}>
                        <img src="/pictures/user-search.svg" alt="reqestes"/>
                        <button title="Пользователи">
                            Пользователи
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default leftMenu;
